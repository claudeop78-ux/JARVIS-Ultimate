# JARVIS Ultimate — Android Starter

This is the first native Android starter project. It provides:
- A dark JARVIS-style Compose interface
- Text input
- Voice input through Android's speech-recognition activity
- Spoken replies through Android TextToSpeech
- A Stop button that stops speech and does not run a background wake-word listener

## Open the project
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Open the extracted `JARVIS_Ultimate_Android_Starter` folder in Android Studio.
4. Let Gradle sync.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press Run.

The project is a starter source project, not a prebuilt APK. It has not been compiled or device-tested in this environment.

## Important current limitations
The reply engine is deliberately local/demo-only. No API key is included and no paid service is required by this starter. A real online AI backend must be configured before it can provide general intelligent answers.

Do not put API keys, passwords, device PINs, banking PINs, or one-time codes in source code or chat. A production build should keep secrets on a secured backend.

## Planned development phases
1. AI brain: provider adapter, adaptive answer length, reasoning, web research, approved memory.
2. Vision: explicit Android MediaProjection consent, OCR, screenshot analysis, puzzle-state recognition.
3. Automation: carefully scoped AccessibilityService, app launching, user-confirmed actions.
4. Communication: Android intents, contact picker, SMS draft/send flow, supported call controls.
5. Creator tools: channel-specific prompt builder, video workflow, YouTube Data API OAuth and upload confirmation.
6. Reliability: permissions dashboard, action history, kill switch, privacy controls, offline fallback.

## Privacy and Android constraints
- Screen capture must be explicitly started and visibly indicated.
- Accessibility access is powerful and must be opt-in, narrowly scoped, and revocable.
- Calls, SMS, Instagram, YouTube and other apps have platform/API restrictions. There is no legitimate universal permission that grants unrestricted control of every app.
- The app must never silently record calls, impersonate the user, or send messages/posts without the required user authorization and confirmation.
- The Stop control is intended to stop active speech immediately. Future background services must remain off unless the user explicitly enables them.

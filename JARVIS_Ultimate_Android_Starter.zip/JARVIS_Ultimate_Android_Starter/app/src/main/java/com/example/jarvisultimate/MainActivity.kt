package com.example.jarvisultimate

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            JarvisApp(
                onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") },
                onStop = { tts?.stop() }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisApp(onSpeak: (String) -> Unit, onStop: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var reply by remember { mutableStateOf("JARVIS systems online. Voice and text interface ready.") }
    var history by remember { mutableStateOf(listOf("You: Welcome, JARVIS.", "JARVIS: Systems online. How may I assist?")) }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        listening = false
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            input = spoken
            reply = localStarterResponse(spoken)
            history = history + "You: $spoken" + "JARVIS: $reply"
            onSpeak(reply)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF48D9F5),
        background = Color(0xFF070B12),
        surface = Color(0xFF111B29)
    )) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF070B12)).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("J.A.R.V.I.S.", color = Color(0xFF55DFF7), fontSize = 27.sp)
            Text("PERSONAL AI SYSTEM  •  STARTER BUILD", color = Color.LightGray, fontSize = 10.sp)
            Spacer(Modifier.height(22.dp))
            Box(
                Modifier.size(150.dp).background(Color(0xFF10283A), RoundedCornerShape(100.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("J", color = Color(0xFF6DE8FF), fontSize = 76.sp)
            }
            Spacer(Modifier.height(18.dp))
            Text(if (listening) "LISTENING…" else "READY", color = Color(0xFF6DE8FF))
            Spacer(Modifier.height(16.dp))
            Text(reply, color = Color.White, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().background(Color(0xFF0D1520), RoundedCornerShape(14.dp)).padding(12.dp)
            ) {
                items(history) { line ->
                    Text(line, color = Color(0xFFD8E8F2), modifier = Modifier.padding(vertical = 5.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Ask JARVIS") },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (input.isNotBlank()) {
                            reply = localStarterResponse(input)
                            history = history + "You: $input" + "JARVIS: $reply"
                            onSpeak(reply)
                            input = ""
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Icon(Icons.Default.Send, contentDescription = null); Text(" Send") }

                Button(
                    onClick = {
                        onStop()
                        listening = false
                        reply = "Stopped. I will not listen or speak in the background."
                        history = history + "JARVIS: $reply"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B2635)),
                    modifier = Modifier.weight(1f)
                ) { Icon(Icons.Default.Stop, contentDescription = null); Text(" Stop") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    onStop()
                    listening = true
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
                    }
                    try { speechLauncher.launch(intent) } catch (_: Exception) {
                        listening = false
                        reply = "Speech recognition is not available on this device."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Icon(Icons.Default.Mic, contentDescription = null); Text("  Talk to JARVIS") }

            Text(
                "Starter build: local demo responses only. Online AI, screen vision and automation are not connected yet.",
                color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}

private fun localStarterResponse(message: String): String {
    val q = message.lowercase(Locale.ROOT)
    return when {
        q.contains("hello") || q.contains("hi") -> "Hello. JARVIS is ready. What would you like to work on?"
        q.contains("time") -> "I can add a live clock module in the next build."
        q.contains("stop") -> "Stopping speech. Background listening is disabled in this starter."
        q.contains("solve") || q.contains("puzzle") -> "I can help solve it once screen capture and the vision engine are added. Please share a screenshot for now."
        else -> "I have received your instruction. The connected AI reasoning engine will be added in the next development phase."
    }
}
